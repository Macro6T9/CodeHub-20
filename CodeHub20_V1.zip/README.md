# CodeHub 20

Write and run code in 20 languages right in your browser. Nothing to install. Free and open source.

## Languages

Each language has its own logo in the [`logos/`](logos) folder (SVG, 32×32 viewBox, scales to any size).

| | Language | | Language | | Language | | Language |
|---|---|---|---|---|---|---|---|
| <img src="logos/python.svg" width="24"> | Python | <img src="logos/html.svg" width="24"> | HTML | <img src="logos/css.svg" width="24"> | CSS | <img src="logos/javascript.svg" width="24"> | JavaScript |
| <img src="logos/typescript.svg" width="24"> | TypeScript | <img src="logos/sql.svg" width="24"> | SQL | <img src="logos/lua.svg" width="24"> | Lua | <img src="logos/java.svg" width="24"> | Java |
| <img src="logos/c.svg" width="24"> | C | <img src="logos/cpp.svg" width="24"> | C++ | <img src="logos/csharp.svg" width="24"> | C# | <img src="logos/php.svg" width="24"> | PHP |
| <img src="logos/go.svg" width="24"> | Go | <img src="logos/rust.svg" width="24"> | Rust | <img src="logos/kotlin.svg" width="24"> | Kotlin | <img src="logos/swift.svg" width="24"> | Swift |
| <img src="logos/ruby.svg" width="24"> | Ruby | <img src="logos/dart.svg" width="24"> | Dart | <img src="logos/r.svg" width="24"> | R | <img src="logos/scala.svg" width="24"> | Scala |

Browser mode (runs locally): HTML, CSS, JavaScript, TypeScript, Python, SQL, Lua.
Server mode (runs through the Judge0 API): Java, C, C++, C#, PHP, Go, Rust, Kotlin, Swift, Ruby, Dart, R, Scala.

## Project structure

Every page is its own folder with an `index.html`, so each URL loads on its own.

```
index.html            Home
editor/               Code editor
languages/            All 20 languages
blog/                 Blog, with three posts inside
login/  signup/       Authentication (Firebase)
profile/  admin/      Account and admin pages
about/  contact/  faq/  terms/  privacy/
donate/               Donate page (crypto wallets, steps and FAQ)
logos/                Language logos (SVG)
qr/                   Donation QR codes (USDT, BTC, ETH)
pay/                  Payment logos (bKash, Nagad, Rocket, Upay, USDT, BTC, ETH)
_redirects            Clean-URL rules for Netlify (no catch-all)
netlify.toml          Netlify settings: publish folder, security and cache headers
404.html              Page shown for unknown URLs
favicon.*, apple-touch-icon.png, site.webmanifest   Browser, phone and app icons
```

The language logos are also embedded inside each page, so the site works without loading any outside image.

## Run it

It is a static site. Serve the folder with any static host (GitHub Pages, Netlify, Firebase Hosting), or locally:

```
python3 -m http.server 8000
```

Then open http://localhost:8000.

## Notes

- Sign-in and saved data use Firebase. Add your own Firebase config before deploying your own copy.
- The logos are simple drawings made for this project, not the official brand marks. Names and logos of the languages belong to their respective owners.

## Source code

The full source is on GitHub: https://github.com/Macro6T9/CodeHub-20. The site links to this repository from the home page, the footer, the About page and the FAQ.

## Donations

The Donate page lists crypto wallets (USDT on TRON TRC20, Bitcoin, Ethereum ERC20). To change an address, edit the `addr` value of the matching entry in `DONATE_WALLETS` in every `index.html`. A card with an empty address shows "Address coming soon". Each entry also has a `qr` value (an inline PNG); replace it and the file in `qr/` when you change an address, and scan it to confirm it decodes to the same address.

The Donate page also has a "Donate from Bangladesh" card (bKash, Nagad, Rocket, Upay, personal Send Money). To change the number, edit it in every `index.html` (search for the `bx-mf` rows).

The payment logos belong to their respective owners and are used only to show which payment method is meant.
